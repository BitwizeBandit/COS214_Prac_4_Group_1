#include "FullTraversalIterator.h"
#include "ProductionUnit.h"

FullTraversalIterator::FullTraversalIterator(ProductionUnit* root) : position(0) {
    if (root != nullptr) {
        buildSnapshot(root);
    }
}

void FullTraversalIterator::buildSnapshot(ProductionUnit* unit) {
    for (WorkComponent* child : unit->children) {
        snapshot.push_back(child);
        ProductionUnit* nested = dynamic_cast<ProductionUnit*>(child);
        if (nested != nullptr) {
            buildSnapshot(nested);
        }
    }
}

void FullTraversalIterator::first() {
    position = 0;
}

void FullTraversalIterator::next() {
    ++position;
}

bool FullTraversalIterator::isDone() const {
    return position >= snapshot.size();
}

WorkComponent* FullTraversalIterator::currentItem() const {
    if (isDone()) {
        return nullptr;
    }
    return snapshot[position];
}
