#include "StoryboardedState.h"
#include "FilmingState.h"
#include "Shot.h"

void StoryboardedState::film(Shot* shot) {
    shot->setState(new FilmingState());
}

std::string StoryboardedState::describe() const {
    return "Storyboarded";
}
