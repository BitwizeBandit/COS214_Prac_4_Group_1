#include "StuntSafetyDecorator.h"
#include <iostream>

StuntSafetyDecorator::StuntSafetyDecorator(WorkComponent* component)
    : Decorator(component) {}

void StuntSafetyDecorator::execute() {
    std::cout << "Running mandatory stunt safety check." << std::endl;
    Decorator::execute();
}

void StuntSafetyDecorator::print(int indent) const {
    std::cout << std::string(static_cast<size_t>(indent) * 2, ' ') << "[STUNT SAFETY]" << std::endl;
    Decorator::print(indent);
}

double StuntSafetyDecorator::computeCost() const {
    return Decorator::computeCost() + 500.0;
}
