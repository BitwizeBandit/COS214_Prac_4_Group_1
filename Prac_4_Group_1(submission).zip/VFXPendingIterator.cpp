#include "VFXPendingIterator.h"
#include "ProductionUnit.h"

VFXPendingIterator::VFXPendingIterator(ProductionUnit* root)
    : root(root), current(nullptr) {}

void VFXPendingIterator::first() {
    frameStack.clear();
    if (root != nullptr) {
        frameStack.push_back(std::make_pair(root, static_cast<std::size_t>(0)));
    }
    current = nullptr;
    advanceToNextMatch();
}

void VFXPendingIterator::next() {
    advanceToNextMatch();
}

void VFXPendingIterator::advanceToNextMatch() {
    while (!frameStack.empty()) {
        ProductionUnit* unit = frameStack.back().first;
        std::size_t idx = frameStack.back().second;

        if (idx >= unit->children.size()) {
            // Exhausted this unit's children - backtrack to its parent frame.
            frameStack.pop_back();
            continue;
        }

        WorkComponent* child = unit->children[idx];
        // Advance THIS frame's cursor before possibly pushing a new frame -
        // push_back below can reallocate frameStack's internal storage, which
        // would invalidate a reference taken into it. Writing the new value
        // by index (not through a held reference) sidesteps that entirely.
        frameStack.back().second = idx + 1;

        ProductionUnit* nested = dynamic_cast<ProductionUnit*>(child);
        if (nested != nullptr) {
            // Descend into it - this is what makes the walk depth-first:
            // the nested unit's children get explored before this frame's
            // remaining siblings.
            frameStack.push_back(std::make_pair(nested, static_cast<std::size_t>(0)));
        }

        if (child->isWaitingOnVFX()) {
            current = child;
            return;
        }
        // No match (and if it was a composite, default isWaitingOnVFX() is
        // false anyway) - loop continues, now processing whatever is on top
        // of the stack (the freshly pushed frame, or this same frame again).
    }
    current = nullptr;
}

bool VFXPendingIterator::isDone() const {
    return current == nullptr;
}

WorkComponent* VFXPendingIterator::currentItem() const {
    return current;
}
