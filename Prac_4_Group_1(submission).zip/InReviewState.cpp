#include "InReviewState.h"
#include "ApprovedState.h"
#include "FilmingState.h"
#include "Shot.h"

void InReviewState::approve(Shot* shot) {
    shot->setState(new ApprovedState());
}

void InReviewState::reject(Shot* shot) {
    shot->setState(new FilmingState());
}

std::string InReviewState::describe() const {
    return "In Review";
}
