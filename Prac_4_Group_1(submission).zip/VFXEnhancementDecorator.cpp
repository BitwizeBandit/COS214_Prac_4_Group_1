#include "VFXEnhancementDecorator.h"
#include <iostream>

VFXEnhancementDecorator::VFXEnhancementDecorator(WorkComponent* component)
    : Decorator(component) {}

void VFXEnhancementDecorator::execute() {
    std::cout << "Applying VFX enhancement pass." << std::endl;
    Decorator::execute();
}

void VFXEnhancementDecorator::print(int indent) const {
    std::cout << std::string(static_cast<size_t>(indent) * 2, ' ') << "[VFX]" << std::endl;
    Decorator::print(indent);
}

double VFXEnhancementDecorator::computeCost() const {
    return Decorator::computeCost() + 3000.0;
}

bool VFXEnhancementDecorator::isWaitingOnVFX() const {
    return true;
}
