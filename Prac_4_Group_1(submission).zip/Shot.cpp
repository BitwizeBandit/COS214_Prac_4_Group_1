#include "Shot.h"
#include "ShotState.h"
#include "StoryboardedState.h"
#include <iostream>

// A new Shot always starts life as Storyboarded - this is the one
// place the initial state is chosen, matching the lifecycle described
// in the design doc (Storyboarded -> Filming -> In Review -> Approved).
Shot::Shot(const std::string& name, bool needsVFX)
    : name(name), state(new StoryboardedState()), needsVFX(needsVFX) {}

Shot::~Shot() {
    // Ownership: Shot owns whichever ShotState is current at the
    // moment it's destroyed (see setState() below for what happens to
    // a state object once it's replaced).
    delete state;
}

// Each lifecycle action is a one-line delegation to whichever
// ShotState object is current. Shot itself never contains an
// if/switch on "what state am I in" - that branching lives entirely
// in the state classes, which is the whole point of the pattern.
void Shot::film() {
    state->film(this);
}

void Shot::submitForReview() {
    state->submitForReview(this);
}

void Shot::approve() {
    state->approve(this);
}

void Shot::reject() {
    state->reject(this);
}

// Called BY a ShotState subclass (e.g. StoryboardedState::film())
// once IT decides a transition is valid - never by client code
// directly. We delete the OLD state object here before swapping in
// the new one: Shot always owns exactly one ShotState at a time, and
// the moment a new one takes over, the old one has no further reason
// to exist.
void Shot::setState(ShotState* newState) {
    delete state;
    state = newState;
}

void Shot::setNeedsVFX(bool waiting) {
    needsVFX = waiting;
}

// "Doing a day's work" on this shot, for the demo scenarios - reports
// its name and current state-dependent description. This call itself
// never changes state; only film()/submitForReview()/approve()/
// reject() do that, via whichever concrete ShotState is current.
void Shot::execute() {
    std::cout << "Working on shot \"" << name << "\" (" << state->describe() << ")";
    if (needsVFX) {
        std::cout << " [awaiting VFX]";
    }
    std::cout << std::endl;
}

void Shot::print(int indent) const {
    std::cout << std::string(static_cast<size_t>(indent) * 2, ' ')
              << "Shot: " << name
              << " [" << state->describe() << "]";
    if (needsVFX) {
        std::cout << " (VFX pending)";
    }
    std::cout << std::endl;
}

std::string Shot::getName() const {
    return name;
}

double Shot::computeCost() const {
    // Flat base cost per shot. A real system might scale this by
    // state (a shot In Review has sunk more cost than one still
    // Storyboarded) - flat is a reasonable starting point that still
    // lets ProductionUnit::computeCost() sum meaningfully up the tree.
    return 500.0;
}

bool Shot::isWaitingOnVFX() const {
    return needsVFX;
}
