#include "ProductionUnit.h"
#include "FullTraversalIterator.h"
#include "VFXPendingIterator.h"
#include <iostream>

ProductionUnit::ProductionUnit(const std::string& name, const std::string& unitType)
    : name(name), unitType(unitType) {}

ProductionUnit::~ProductionUnit() {
    for (WorkComponent* child : children) {
        delete child;
    }
    children.clear();
}

void ProductionUnit::add(WorkComponent* component) {
    children.push_back(component);
}

void ProductionUnit::remove(WorkComponent* component) {
    for (auto it = children.begin(); it != children.end(); ++it) {
        if (*it == component) {
            children.erase(it);
            return;
        }
    }
}

WorkIterator* ProductionUnit::createIterator(IteratorType type) {
    switch (type) {
        case IteratorType::FULL_TRAVERSAL:
            return new FullTraversalIterator(this);
        case IteratorType::VFX_PENDING:
            return new VFXPendingIterator(this);
    }
    return nullptr;
}

void ProductionUnit::execute() {
    std::cout << "[" << unitType << "] " << name << " is coordinating its work..." << std::endl;
    for (WorkComponent* child : children) {
        child->execute();
    }
}

void ProductionUnit::print(int indent) const {
    std::cout << std::string(static_cast<size_t>(indent) * 2, ' ')
              << unitType << ": " << name << std::endl;
    for (const WorkComponent* child : children) {
        child->print(indent + 1);
    }
}

std::string ProductionUnit::getName() const {
    return name;
}

double ProductionUnit::computeCost() const {
    double total = 0.0;
    for (const WorkComponent* child : children) {
        total += child->computeCost();
    }
    return total;
}

const std::string& ProductionUnit::getUnitType() const {
    return unitType;
}
