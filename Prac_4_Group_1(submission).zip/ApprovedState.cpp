#include "ApprovedState.h"

std::string ApprovedState::describe() const {
    return "Approved";
}
