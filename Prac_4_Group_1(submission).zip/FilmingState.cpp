#include "FilmingState.h"
#include "InReviewState.h"
#include "Shot.h"

void FilmingState::submitForReview(Shot* shot) {
    shot->setState(new InReviewState());
}

std::string FilmingState::describe() const {
    return "Filming";
}
